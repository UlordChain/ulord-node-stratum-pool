一.输入命令：./Ulordrig开始挖矿；线程数，地址在config文件中可修改。

二.命令行（部分）参数，输入./Ulordrig -h(Ulordrig.exe -help)可以查看帮助
  -o 矿池URL
  -O ulord钱包地址.编号：密码，例如：ueC7gxTP34dE1WGTm51TG9WF3rLifcyND6.test01:x 
  -t 挖矿线程数
示例：./Ulordrig -o stratum+tcp://test-pool.ulord.one:7200 -O ueC7gxTP34dE1WGTm51TG9WF3rLifcyND6.test:x -t 4

